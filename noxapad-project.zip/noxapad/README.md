# NoxaPad

Proyecto frontend inspirado en la interfaz pública de GrokPad, con identidad NoxaPad.

## Ejecutar

No necesita compilación ni dependencias. Desde la raíz:

```sh
python3 -m http.server 8080 --directory dist
```

Abre `http://localhost:8080`.

## Estructura

- `dist/index.html`: página principal.
- `dist/{launch,coins,my,feed,terminal,docs}/index.html`: rutas.
- `dist/assets/app.js`: comportamiento, formularios, validación y estado local.
- `dist/assets/noxapad.css`: estilos adicionales y adaptación móvil.
- `dist/assets/reference.css`: estilos visuales preservados de la referencia.
- `dist/assets/noxapad.svg`: marca del proyecto.
- `.openai/hosting.json`: configuración del sitio.

## Funcionalidad

Formulario con previsualización, imagen local opcional, seis personalidades, instrucciones del agente, campos sociales, cálculo ilustrativo de comisiones, validación, wallet de demostración, tokens locales persistentes, búsqueda, ordenación, tarjetas, exportación JSON, feed de ejemplo y terminal simulado con filtros, pausa y limpieza.

Los tokens se guardan en localStorage (`noxapad.tokens`). El borrador se guarda en `noxapad.draft`. La demo no recopila claves privadas ni solicita firmas.

## Integraciones pendientes

No incluye minting real, wallet Solana, servicios RPC, transacciones, datos en vivo ni API de IA. El mercado y los agentes son simulados y están identificados como demo. Para producción harían falta un backend de agentes, almacenamiento persistente y las integraciones blockchain correspondientes.

## Referencia

Diseño adaptado de https://grokpad.space/ a petición del usuario. Los scripts originales no se ejecutan. El comportamiento de esta versión se implementa en `app.js`.
